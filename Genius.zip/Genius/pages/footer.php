<link rel="stylesheet" href="../css/style.css">
<footer>
    
</footer>
<link rel="stylesheet" href="../css/style.css">
<header>
    <?php 
    
    include("navigation.php");
    ?>
</header>
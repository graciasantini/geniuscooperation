<link rel="stylesheet" href="../css/style.css">
<nav>
    <img src="images/logo.ico" alt="logo du site" class="logo">
    <div class="bare_menu">
        <img src="" alt="A" class="ouvrir">
        <img src="" alt="b" class="fermer">
    </div>
    <ul class="menu">
        <li><a href="">Accueil</a></li>
        <li><a href="">Nos services</a></li>
        <li><a href="">Nous contacter</a></li>
        <li><a href="">A propos de nous</a></li>
    </ul>
</nav>